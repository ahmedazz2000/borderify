

document.body.style.border = "5px solid red";






var time_gap=0;
var old_text='';
function getSelectionText(e) {
//$( "body" ).append('<div id="selected_text" style="display:none;"></div>');
    var text = "";
    if (window.getSelection) {
        text = window.getSelection().toString();
    }
	else if (document.selection && document.selection.type != "Control") {
        text = document.selection.createRange().text;
    }
	text= text.replace(/[^a-zA-Z ]/g, "");
	
	
		//text.length <=20 && 
	if(text.length > 1){
			if(!document.getElementById("new_elemt_ext")){
    var txt = document.createElement("div");
    txt.innerHTML = '<span id="new_elemt_ext" style="z-index:99999;position:fixed;bottom:0px;left: 0px;padding: 10px;margin: 30px;background-color: black;font-size: 25px;color: white;">'+text+'<br><span id="new_elemt_ext_ar"></span></span>';	
	document.body.appendChild(txt); 
	}
	else{document.getElementById("new_elemt_ext").innerHTML=''+text;}
	
		
		
	$.ajax({
	url: "http://192.168.8.100/dictionary/translate.php",
	method: "GET",
	data: { search_word: text},
	timeout: 7000,
	cache: false
})
	.done(function( html ) {
		document.getElementById("new_elemt_ext_ar").innerHTML=html;
});
	
	}

	}







//= document.onkeyup = document.onselectionchange
document.onmouseup  = function(e) {
 getSelectionText(e);
};

